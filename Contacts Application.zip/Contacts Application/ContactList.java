/*ContactList.java
 * 11/30/2016
 * Izzy Shpilman
 * adds the contact objects to array list of contacts
 */

import java.util.ArrayList;

class ContactList{
  
  //creates the arraylist for all of the contacts
  private ArrayList<Contacts> list;
  
  ContactList(){
    list = new ArrayList<Contacts>();
  }
  
  //adding the contacts to the contactlist
  
  public void addContact (Contacts person){
    list.add(person);
    for (int i = 0; i<list.size(); i++){
      System.out.println((list.get(i)).getName());
    }
    System.out.println(list.size());
    return;
  }

}

