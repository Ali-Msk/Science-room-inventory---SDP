/*Family contact
 * 11/29/2016
 * relationship to person
 * Israel Shpilman
 */

class FamilyContact extends Contacts{
  private String whichMember;
  
  FamilyContact(String name, String address, String email, String phoneNumber, String whichMember){
    super(name, address, email, phoneNumber);
    this.whichMember = whichMember;
  }
  
  //finding which member
  public String getWhichMember(){
    return this.whichMember;
  }
  
  //setting the member
  public void setWhichMember(String whichMember){
    this.whichMember = whichMember;
  }
}
                              