/*business contact
 * 11/29/2016
 * relationship to person
 * Israel Shpilman
 */

class BusinessContact extends Contacts{
  private String title;
  private String companyName;
  
  BusinessContact(String name, String address, String email, String phoneNumber, String title, String companyName){
    super(name, address, email, phoneNumber);
    this.title = title;
    this.companyName = companyName;
  }
  
  //finding title
  public String getTitle(){
    return this.title;
  }
  
  //setting the title
  public void setTitle(String title){
    this.title = title;
  }
  
  //finding company name
  public String getCompanyName(){
    return this.companyName;
  }
  
  //setting the company name
  public void setCompanyName(String companyName){
    this.companyName = companyName;
  }
}