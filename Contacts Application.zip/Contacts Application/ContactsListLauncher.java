/*contactslistlauncher.java
 * 11/30/2016
 * Israel Shpilman
 * launches the whole program to run
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ContactsListLauncher {
  public static void main (String [] args){
 ContactGui newContacts = new ContactGui();
 
  }
}