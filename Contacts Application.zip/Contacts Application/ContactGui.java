/*ContactGui.java
 * 12/1/2016
 * Israel Shpilman
 * Creates gui for adding contacts
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ContactGui extends JFrame{
  //creating contact objects
  private FriendContact friend;
  private FamilyContact family;
  private BusinessContact business;
  
  // creating contact list
  private ContactList contactlist;
  
  //creating buttons
  private JButton contactRemoverButton;
  private JButton familyContactButton;
  private JButton friendContactButton;
  private JButton businessContactButton;
  private JButton editContactButton;
  private JButton removeContactButton;
  
  //creating panels for contacts
  private JPanel contactList;
  private JPanel familyContact;
  private JPanel friendContact;
  private JPanel businessContact;
  private JPanel editContact;
  private JPanel removeContact;
  private JPanel mainContact;
  
  //adding panels for border layout
  private JPanel familyBorder;
  private JPanel friendBorder;
  private JPanel businessBorder;
  
  //adding panels for grid layout
  private JPanel familyGrid;
  private JPanel friendGrid;
  private JPanel businessGrid;
  
  //creating text fields for friend contacts
  private JTextField name;
  private JTextField address;
  private JTextField email;
  private JTextField phoneNumber;
  
  //creating text fields for family contacts
  private JTextField familyName;
  private JTextField familyAddress;
  private JTextField familyEmail;
  private JTextField familyPhoneNumber;
  
  //creating text fields for business contacts
  private JTextField businessName;
  private JTextField businessAddress;
  private JTextField businessEmail;
  private JTextField businessPhoneNumber;
  
  //creating text fields for the family contact
  private JTextField whichMember;
  
  //creating text fields for friend contact
  private JTextField meetingPlace;
  
  //creating text fields for business contact
  private JTextField  title;
  private JTextField companyName;
  
  //creating labels for main contacts
  private JLabel nameLabel; 
  private JLabel addressLabel; 
  private JLabel emailLabel; 
  private JLabel phoneNumberLabel; 
  
  //creating labels for family contacts
  private JLabel familyNameLabel;
  private JLabel familyAddressLabel;
  private JLabel familyEmailLabel;
  private JLabel familyPhoneNumberLabel;
  
  //creating labels for business contacts
  private JLabel businessNameLabel;
  private JLabel businessAddressLabel; 
  private JLabel businessEmailLabel; 
  private JLabel businessPhoneNumberLabel;
  
  //creating a label for the family contact
  private JLabel whichMemberLabel; 
  
  //creating a label for the friend contact
  private JLabel meetingPlaceLabel; 
  
  //creating labels for the business contact
  private JLabel titleLabel; 
  private JLabel companyNameLabel;
  
  //adding different contacts to contact tabbed pane
  private JTabbedPane contact;
  
  //making another tabbed pane
  private JTabbedPane mainPane;
  
  
  
  ContactGui(){
    //creating contactlist
    contactlist = new ContactList();
    //creates the tabs panes and buttons
    JFrame myWindow = new JFrame("Contacts List");//creates a new window to work with
    myWindow.setSize(600,400);//set size of window by 400 by 400 pixals
    myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //sets the program to close when the window closes
    
    
    //buttons
    familyContactButton = new JButton("Add Family Contact");
    friendContactButton = new JButton("Add Friend Contact");
    businessContactButton = new JButton("Add Business Contact");
    editContactButton = new JButton("Edit Contact");
    removeContactButton = new JButton("Remove Contact");
    
    //Creating an action listener for buttons
    familyContactButton.addActionListener(new familyButtonListener());
    friendContactButton.addActionListener(new friendButtonListener());
    businessContactButton.addActionListener(new businessButtonListener());
    editContactButton.addActionListener(new editButtonListener());
    removeContactButton.addActionListener(new removeButtonListener());
    
    //creating panels for contacts
    contactList = new JPanel();
    familyContact = new JPanel();
    friendContact = new JPanel();
    businessContact = new JPanel();
    editContact = new JPanel();
    removeContact = new JPanel();
    mainContact = new JPanel();
    mainContact.setLayout(new GridLayout(1,1));
    
    //creating text fields for friend contacts
    name = new JTextField();
    address = new JTextField();
    email = new JTextField();
    phoneNumber = new JTextField();
    
    //creating text fields for family contact
    familyName = new JTextField();
    familyAddress = new JTextField();
    familyEmail = new JTextField();
    familyPhoneNumber = new JTextField();
    
    //creating text fields for business contact
    businessName = new JTextField();
    businessAddress = new JTextField();
    businessEmail = new JTextField();
    businessPhoneNumber = new JTextField();
    
    //creating text fields for the family contact
    whichMember = new JTextField();
    
    //creating text fields for friend contact
    meetingPlace = new JTextField();
    
    //creating text fields for business contact
    title = new JTextField();
    companyName = new JTextField();
    
    //creating labels for friends contacts
    nameLabel = new JLabel("Name:"); 
    addressLabel = new JLabel("Address:"); 
    emailLabel = new JLabel("Email:"); 
    phoneNumberLabel = new JLabel("Phone Number:"); 
    
    //creating labels for family contacts
    familyNameLabel = new JLabel("Name:"); 
    familyAddressLabel = new JLabel("Address:"); 
    familyEmailLabel = new JLabel("Email:"); 
    familyPhoneNumberLabel = new JLabel("Phone Number:"); 
    
    //creating labels for business contacts
    businessNameLabel = new JLabel("Name:"); 
    businessAddressLabel = new JLabel("Address:"); 
    businessEmailLabel = new JLabel("Email:"); 
    businessPhoneNumberLabel = new JLabel("Phone Number:"); 
    
    //creating a label for the family contact
    whichMemberLabel = new JLabel("What Family Member are they:"); 
    
    //creating a label for the friend contact
    meetingPlaceLabel = new JLabel("Where did you meet them:"); 
    
    //creating labels for the business contact
    titleLabel = new JLabel("Title:"); 
    companyNameLabel = new JLabel("Company Name:"); 
    
    //making border layout panels
    familyBorder = new JPanel();
    friendBorder = new JPanel();
    businessBorder = new JPanel();
    
    //creating a grid layout
    familyGrid = new JPanel();
    familyGrid.setLayout(new GridLayout(5,2));
    friendGrid = new JPanel();
    friendGrid.setLayout(new GridLayout(5,2));
    businessGrid = new JPanel();
    businessGrid.setLayout(new GridLayout(6,2));
    
    //adding stuff to family grid layout
    familyGrid.add(familyNameLabel);
    familyGrid.add(familyName);
    familyGrid.add(familyAddressLabel);
    familyGrid.add(familyAddress);
    familyGrid.add(familyEmailLabel);
    familyGrid.add(familyEmail);
    familyGrid.add(familyPhoneNumberLabel);
    familyGrid.add(familyPhoneNumber);
    familyGrid.add(whichMemberLabel);
    familyGrid.add(whichMember);
    
    //adding stuff to friend grid layout
    friendGrid.add(nameLabel);
    friendGrid.add(name);
    friendGrid.add(addressLabel);
    friendGrid.add(address);
    friendGrid.add(emailLabel);
    friendGrid.add(email);
    friendGrid.add(phoneNumberLabel);
    friendGrid.add(phoneNumber);
    friendGrid.add(meetingPlaceLabel);
    friendGrid.add(meetingPlace);
    
    //adding stuff to business grid layout
    businessGrid.add(businessNameLabel);
    businessGrid.add(businessName);
    businessGrid.add(businessAddressLabel);
    businessGrid.add(businessAddress);
    businessGrid.add(businessEmailLabel);
    businessGrid.add(businessEmail);
    businessGrid.add(businessPhoneNumberLabel);
    businessGrid.add(businessPhoneNumber);
    businessGrid.add(titleLabel);
    businessGrid.add(title);
    businessGrid.add(companyNameLabel);
    businessGrid.add(companyName);
    
    //creating a border layout
    familyBorder.setLayout(new BorderLayout());
    friendBorder.setLayout(new BorderLayout());
    businessBorder.setLayout(new BorderLayout());
    
    //adding stuff to border layout
    familyBorder.add(familyGrid,BorderLayout.CENTER);
    familyBorder.add(familyContactButton,BorderLayout.SOUTH);
    friendBorder.add(friendGrid,BorderLayout.CENTER);
    friendBorder.add(friendContactButton,BorderLayout.SOUTH);
    businessBorder.add(businessGrid,BorderLayout.CENTER);
    businessBorder.add(businessContactButton,BorderLayout.SOUTH);
    
    //adding buttons in
    editContact.add(editContactButton);
    removeContact.add(removeContactButton);
    
    //adding different contacts to contact tabbed pane
    contact = new JTabbedPane();
    familyContact.add(familyBorder);
    friendContact.add(friendBorder);
    businessContact.add(businessBorder);
    contact.add("Family Contact",familyContact);
    contact.add("Friend Contact",friendContact);
    contact.add("Business Contact",businessContact);
    
    //adding contact tabbed pane to mainContact
    mainContact.add(contact);
    
    //adding the different stuff to do with contacts to the main tabbed pane
    mainPane = new JTabbedPane();
    mainPane.add("Contact List", contactList);
    mainPane.add("Contact Adder", mainContact);
    mainPane.add("Contact Editor", editContact);
    mainPane.add("Contact Remover", removeContact);
    
    //adding to window
    myWindow.add(mainPane);
    myWindow.setVisible(true);
  }
  //implementing the action listener
  class familyButtonListener implements ActionListener {
    public  void actionPerformed(ActionEvent event) { 
      System.out.println("FAMILY");
      family = new FamilyContact(familyName.getText(), familyAddress.getText(), familyEmail.getText(), familyPhoneNumber.getText(), whichMember.getText());
      contactlist.addContact(family);
      //reseting the fields
      familyName.setText(" ");
      familyAddress.setText(" ");
      familyEmail.setText(" ");
      familyPhoneNumber.setText(" ");
      whichMember.setText(" ");
      
    }
  }
  //implementing the action listener
  class friendButtonListener implements ActionListener {
    public  void actionPerformed(ActionEvent event) { 
      
      System.out.println("FRIEND");
      friend = new FriendContact(name.getText(), address.getText(), email.getText(), phoneNumber.getText(), meetingPlace.getText());
      contactlist.addContact(friend);
      //reseting the fields
      name.setText(" ");
      address.setText(" ");
      email.setText(" ");
      phoneNumber.setText(" ");
      meetingPlace.setText(" ");
      
    }
  }
  //implementing the action listener
  class businessButtonListener implements ActionListener {
    public  void actionPerformed(ActionEvent event) { 
      
      System.out.println("BUSINESS");
      business = new BusinessContact(businessName.getText(), businessAddress.getText(), businessEmail.getText(), businessPhoneNumber.getText(), title.getText(), companyName.getText());
      contactlist.addContact(family);
      //reseting the fields
      businessName.setText(" ");
      businessAddress.setText(" ");
      businessEmail.setText(" ");
      businessPhoneNumber.setText(" ");
      title.setText(" ");
      companyName.setText(" ");
      
    }
  }
  //implementing the action listener
  class editButtonListener implements ActionListener {
    public  void actionPerformed(ActionEvent event) { 
      
      System.out.println("EDIT");
      
    }
  }
  //implementing the action listener
  class removeButtonListener implements ActionListener {
    public  void actionPerformed(ActionEvent event) { 
      
      System.out.println("REMOVE");
      
    }
  }
}
