/*ContactsList.java
 * Israel Shpilman
 * 11/28/2016
 * creating an object for the person to enter contact info
 */

abstract class Contacts{
  //variables
  private String name;
  private String address;
  private String email;
  private String phoneNumber;
  
 // constructor contact list 
  Contacts (String name, String address, String email, String phoneNumber){
    this.name = name;
    this.address = address;
    this.email = email;
    this.phoneNumber = phoneNumber;
  }
  
  //getting the name
  public String getName(){
    return this.name;
  }
  
  //setting the name
  public void setName(String name){
    this.name = name;
  }
  
   //getting the address
  public String getAddress(){
    return this.address;
  }
  
  //setting the address
  public void setAddress(String address){
    this.address = address;
  } 
  
     //getting the email
  public String getEmail(){
    return this.email;
  }
  
  //setting the email
  public void setEmail(String email){
    this.email = email;
  } 
  
       //getting the phoneNumber
  public String getPhoneNumber(){
    return this.phoneNumber;
  }
  
  //setting the phoneNumber
  public void setPhoneNumber(String phoneNumber){
    this.phoneNumber = phoneNumber;
  } 
}