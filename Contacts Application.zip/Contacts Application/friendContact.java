/* Friend contact
 * 11/29/2016
 * Israel Shpilman
 * puts friend contacts here
 */

class FriendContact extends Contacts{
  private String meetingPlace;
  
  FriendContact(String name, String address, String email, String phoneNumber, String meetingPlace){
    super(name, address, email, phoneNumber);
    this.meetingPlace = meetingPlace; 
  }
  
  //finding meetingplace
  public String getMeetingPlace(){
    return this.meetingPlace;
  }
  
  //setting the meeting place
  public void setMeetingPlace(String meetingPlace){
    this.meetingPlace = meetingPlace;
  }
}
  